﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantTest
{
    class Restaurant
    {
        public int CoffePrice(string coffe)
        {
            int price = 0;
            switch (coffe)
            {
                case "huge":
                    price = 20;
                    break;
                case "big":
                    price = 15;
                    break;
                case "medium":
                    price =13;
                    break;
                case "small":
                    price = 8;
                    break;
            }
            return price;
        }
        public int TotalPrice(int amountCoffe, string sizeCoffe)
        {
            int priceCoffe = CoffePrice(sizeCoffe);
            int total = amountCoffe * priceCoffe;
            return total;
        }
       
        public double AveragePriceOfCoffe(string[] myArr)
        {
            int[] price = new int[5];
            for (int i=0; i < myArr.Length; i++)
            {
                 price[i] = CoffePrice(myArr[i]);
            }
            int total = 0;
            for (int i = 0; i < myArr.Length; i++)
            {
                total = total + price[i];
            }
            double average = (double)(total) / 5;
            return average;
        } 
        public int PriceOfFiveCoffe(string[] myArr)
        {


            int n = 0;
            string[] arrangedArr = new string[5];
            for (int i = 0; i < myArr.Length; i++)
            {
                if (myArr[i] == "huge")
                {
                    arrangedArr[n] = myArr[i];
                    n++;
                }
            }
            for (int i = 0; i < myArr.Length; i++)
            {
                if (myArr[i] == "big")
                {
                    arrangedArr[n] = myArr[i];
                    n++;
                }
            }
            for (int i = 0; i < myArr.Length; i++)
            {
                if (myArr[i] == "medium")
                {
                    arrangedArr[n] = myArr[i];
                    n++;
                }
            }
            for (int i = 0; i < myArr.Length; i++)
            {
                if (myArr[i] == "small")
                {
                    arrangedArr[n] = myArr[i];
                    n++;
                }
            }
            int[] price = new int[5];
            for (int i = 0; i < myArr.Length; i++)
            {
                price[i] = CoffePrice(myArr[i]);
            }
            int total = 0;
            for (int i = 0; i < myArr.Length; i++)
            {
                total = total + price[i];
            }
            return total;
        }
    }
}
