﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RestaurantTest
{
    [TestClass]
    public class RestaurantUnitTest
    {
        [TestMethod]
        public void CoffePrice()
        {
            Restaurant restaurant = new Restaurant();
            string param1 = "big";
            int expected1 = 15;
            int actual1 = restaurant.CoffePrice(param1);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");
            string param2 = "small";
            int expected2 = 8;
            int actual2 = restaurant.CoffePrice(param2);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");

        }
        [TestMethod]
        public void TotalPrice()
        {
            Restaurant restaurant = new Restaurant();
            int param11 = 3;
            string param12 = "medium";
            int expected1 = 39;
            int actual1= restaurant.TotalPrice(param11, param12);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void AveragePriceOfCoffe()
        {
            Restaurant restaurant = new Restaurant();
            string[] param1 = { "big", "medium", "huge", "small", "small"};
            double expected1 = 12.8;
            double actual1 = restaurant.AveragePriceOfCoffe(param1);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");
        }
        [TestMethod]
        public void PriceOfFiveCoffe()
        {
            Restaurant restaurant = new Restaurant();
            string[] param1 = {"small", "medium", "huge","big", "small"};
            int expected1 = 64;
            int actual1 = restaurant.PriceOfFiveCoffe(param1);
            Assert.AreEqual(expected1, actual1, 0, "THE RESUELT IS INCORRECT");

        }
    }
}
